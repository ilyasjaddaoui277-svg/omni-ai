/* ============================================================
   OmniAI — main.js
   Vanilla JS · Zero dependencies · Zero console errors
   ============================================================ */
(function () {
  'use strict';

  /* ---------- 1. Navbar scroll state ---------- */
  var nav = document.querySelector('.site-nav');
  if (nav) {
    var onScroll = function () {
      if (window.scrollY > 24) { nav.classList.add('scrolled'); }
      else { nav.classList.remove('scrolled'); }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- 2. Mobile menu toggle ---------- */
  var menuBtn = document.querySelector('[data-menu-toggle]');
  var mobileMenu = document.querySelector('[data-mobile-menu]');
  if (menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', function () {
      var isOpen = mobileMenu.classList.toggle('open');
      menuBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  }

  /* ---------- 3. Feature tabs ---------- */
  var tabBtns = document.querySelectorAll('[data-tab-btn]');
  if (tabBtns.length) {
    tabBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var target = btn.getAttribute('data-tab-btn');
        tabBtns.forEach(function (b) { b.classList.toggle('active', b === btn); });
        document.querySelectorAll('[data-tab-panel]').forEach(function (p) {
          p.classList.toggle('active', p.getAttribute('data-tab-panel') === target);
        });
      });
    });
  }

  /* ---------- 4. FAQ accordion ---------- */
  document.querySelectorAll('[data-accordion] .acc-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = btn.closest('.acc-item');
      var body = item.querySelector('.acc-body');
      var isOpen = item.classList.contains('open');
      // Close siblings
      item.parentElement.querySelectorAll('.acc-item.open').forEach(function (o) {
        o.classList.remove('open');
        o.querySelector('.acc-body').style.maxHeight = null;
        o.querySelector('.acc-btn').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        body.style.maxHeight = body.scrollHeight + 'px';
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  });

  /* ---------- 5. Pricing toggle (monthly / annual) ---------- */
  var billingSwitch = document.querySelector('[data-billing-switch]');
  if (billingSwitch) {
    billingSwitch.addEventListener('click', function () {
      var annual = billingSwitch.classList.toggle('annual');
      document.querySelectorAll('[data-price]').forEach(function (el) {
        var val = annual ? el.getAttribute('data-annual') : el.getAttribute('data-monthly');
        el.textContent = val;
      });
      document.querySelectorAll('.save-pill').forEach(function (p) { p.classList.toggle('on', annual); });
      document.querySelectorAll('[data-period]').forEach(function (el) {
        el.textContent = annual ? '/year' : '/month';
      });
    });
  }

  /* ---------- 6. Animated counters ---------- */
  var counters = document.querySelectorAll('[data-counter]');
  if (counters.length && 'IntersectionObserver' in window) {
    var runCounter = function (el) {
      var target = parseFloat(el.getAttribute('data-counter'));
      var suffix = el.getAttribute('data-suffix') || '';
      var dur = 1600, start = null;
      var step = function (ts) {
        if (!start) { start = ts; }
        var p = Math.min((ts - start) / dur, 1);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(target * eased).toLocaleString('en-US') + suffix;
        if (p < 1) { requestAnimationFrame(step); }
      };
      requestAnimationFrame(step);
    };
    var cObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { runCounter(e.target); cObs.unobserve(e.target); }
      });
    }, { threshold: 0.4 });
    counters.forEach(function (c) { cObs.observe(c); });
  }

  /* ---------- 7. Reveal on scroll ---------- */
  var reveals = document.querySelectorAll('.reveal');
  if (reveals.length && 'IntersectionObserver' in window) {
    var rObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('visible'); rObs.unobserve(e.target); }
      });
    }, { threshold: 0.12 });
    reveals.forEach(function (r) { rObs.observe(r); });
  } else {
    reveals.forEach(function (r) { r.classList.add('visible'); });
  }

  /* ---------- 8. Animate dashboard chart bars on load ---------- */
  var chart = document.querySelector('[data-chart]');
  if (chart) {
    var bars = chart.querySelectorAll('.chart-bar');
    setTimeout(function () {
      bars.forEach(function (b) { b.style.height = b.getAttribute('data-h') + '%'; });
    }, 250);
  }

  /* ---------- 9. Docs sidebar scroll-spy ---------- */
  var docLinks = document.querySelectorAll('.doc-link[href^="#"]');
  if (docLinks.length) {
    var sections = [];
    docLinks.forEach(function (l) {
      var sec = document.querySelector(l.getAttribute('href'));
      if (sec) { sections.push({ link: l, sec: sec }); }
    });
    var spy = function () {
      var pos = window.scrollY + 140;
      var current = sections[0];
      sections.forEach(function (s) { if (s.sec.offsetTop <= pos) { current = s; } });
      docLinks.forEach(function (l) { l.classList.remove('active'); });
      if (current) { current.link.classList.add('active'); }
    };
    window.addEventListener('scroll', spy, { passive: true });
    spy();
  }
})();

/* ============================================================
   OmniAI v1.1 — Pro Upgrade Pack (vanilla JS)
   ============================================================ */
(function () {
  'use strict';

  /* ---------- 1. Hero typing effect ---------- */
  var typedEl = document.querySelector('[data-typed]');
  if (typedEl) {
    var words = (typedEl.getAttribute('data-typed-words') || '').split('|').filter(Boolean);
    var cursor = typedEl.parentElement.querySelector('.typed-cursor');
    if (words.length) {
      var wi = 0, ci = 0, deleting = false;
      var tick = function () {
        var word = words[wi];
        if (!deleting) {
          ci++;
          if (ci === word.length) {
            typedEl.textContent = word;
            deleting = true;
            setTimeout(tick, 2400);
            return;
          }
        } else {
          ci--;
          if (ci === 0) { deleting = false; wi = (wi + 1) % words.length; }
        }
        typedEl.textContent = word.slice(0, ci);
        if (cursor) { cursor.style.display = ''; }
        setTimeout(tick, deleting ? 34 : 72);
      };
      tick();
    }
  }

  /* ---------- 2. Toast notifications ---------- */
  var toastEl = null, toastTimer = null;
  window.omniToast = function (message) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'toast';
      toastEl.setAttribute('role', 'status');
      toastEl.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg><span></span>';
      document.body.appendChild(toastEl);
    }
    toastEl.querySelector('span').textContent = message;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, 3800);
  };

  /* ---------- 3. Form validation (demo) ---------- */
  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var valid = true;
      form.querySelectorAll('[required]').forEach(function (input) {
        var wrap = input.closest('div');
        var msg = wrap ? wrap.querySelector('.form-msg') : null;
        var val = input.value.trim();
        var bad = !val;
        if (!bad && input.type === 'email') { bad = !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val); }
        if (!bad && input.minLength > 0 && val.length < input.minLength) { bad = true; }
        input.classList.toggle('field-error', bad);
        if (msg) { msg.classList.toggle('show', bad); }
        if (bad) { valid = false; }
      });
      if (valid) {
        window.omniToast(form.getAttribute('data-success') || 'Submitted successfully!');
        form.reset();
        form.querySelectorAll('.field-error').forEach(function (i) { i.classList.remove('field-error'); });
        form.querySelectorAll('.form-msg.show').forEach(function (m) { m.classList.remove('show'); });
      }
    });
  });

  /* ---------- 4. Newsletter + demo toast hooks ---------- */
  document.querySelectorAll('[data-toast]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      e.preventDefault();
      window.omniToast(el.getAttribute('data-toast'));
    });
  });

  /* ---------- 5. Back to top ---------- */
  var backTop = document.querySelector('.back-top');
  if (backTop) {
    var toggleTop = function () {
      backTop.classList.toggle('show', window.scrollY > 600);
    };
    window.addEventListener('scroll', toggleTop, { passive: true });
    backTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    toggleTop();
  }
})();
